// Supabase connection. The publishable key is public by design;
// all access is controlled by the row level security policies in supabase/schema.sql.
// Never put the secret key (sb_secret_...) in this file.
window.HELP_LIVE = {
  url: "https://pquvwrzfpkqfutvxffba.supabase.co",
  key: "sb_publishable_0xuBhcigKQLZhzdRz81a4Q_KF6ZPHnr"
};
