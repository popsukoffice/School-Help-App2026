# Help at School – LIVE (child tablet -> staff tablets)

## Files (upload these to GitHub, top level)
- `index.html`      child app
- `staff.html`      adults' live queue (sign in, alerts, On my way / Resolved, change password)
- `admin.html`      set up schools and manage adults (POPS admins and school admins)
- `config.js`       Supabase URL + publishable key
- `manifest.webmanifest`, `logo.jpg`
- `supabase/`       `schema.sql` (base), `migrations/002_admin.sql`, `functions/admin/index.ts` (Edge Function), `seed.sql`

## Everyday use
- New school: open `/admin.html`, sign in as a POPS admin, "Set up a new school": type the name and paste adults,
  one per line: `email, name children see, admin`. You get the school code, staff PIN and a temporary password per adult (shown once; print or copy).
- New adult / leaver / forgotten password / lost PIN: `/admin.html` > Manage (POPS admins) or sign in as the school's admin.
- Child tablet: open the site, "Connect to my school", type the school code, Add to Home Screen.
- Adult tablet: open `/staff.html`, sign in, turn on alerts, Add to Home Screen.

## Roles
- POPS admin = row in `platform_admins` (insert by SQL, see migrations/002_admin.sql).
- School admin = `staff.is_admin = true` (can add adults, reset passwords, rotate the code/PIN for their school only).
- All admin actions run in the `admin` Edge Function (service key stays on the server).

## Routing
Named adult -> that adult alerted; nobody named or "I need an adult now" -> all staff;
named adult silent for 2 minutes -> everyone ("NOT YET ANSWERED"); urgent repeats every 10 s.

## Before real pupils
DPIA + data-processing agreement per school; 30-day retention job (schema.sql); rate-limit sign-up / pair / PIN calls;
Supabase Pro (free projects pause); Vercel: turn off Deployment Protection so tablets can open the site;
not an emergency service (tablets must stay awake with the page open).
