// Help at School - admin Edge Function (POPS UK)
// Lets POPS platform admins create schools and lets school admins manage their own adults.
// Uses the service role key (provided automatically by Supabase) - never expose it to the browser.
import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

const CODE = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
const PW = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
const rand = (n: number, alphabet: string) =>
  Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => alphabet[b % alphabet.length]).join("");
const clean = (s: unknown, max: number) => String(s ?? "").trim().replace(/\s+/g, " ").slice(0, max);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
  const { data: auth } = await sb.auth.getUser(token);
  const user = auth?.user;
  if (!user || user.is_anonymous) return json({ error: "Please sign in." }, 401);

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "Bad request" }, 400); }

  try {
    const { data: pa } = await sb.from("platform_admins").select("user_id").eq("user_id", user.id).maybeSingle();
    const platform = !!pa;
    const { data: me } = await sb.from("staff")
      .select("id, school_id, display_name, is_admin, active, schools(name, pair_code, staff_pin)")
      .eq("id", user.id).maybeSingle();
    const schoolAdmin = !!(me && me.active && me.is_admin);
    const canManage = (schoolId: string) => platform || (schoolAdmin && me!.school_id === schoolId);

    async function createAdults(schoolId: string, adults: any[]) {
      const out: any[] = [];
      for (const a of (Array.isArray(adults) ? adults : []).slice(0, 50)) {
        const email = clean(a.email, 160).toLowerCase();
        const name = clean(a.display_name, 80);
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !name) {
          out.push({ email, display_name: name, error: "Needs a valid email and a name" });
          continue;
        }
        const password = rand(12, PW);
        const { data, error } = await sb.auth.admin.createUser({ email, password, email_confirm: true });
        if (error || !data.user) {
          out.push({ email, display_name: name, error: /already|registered|exists/i.test(error?.message ?? "")
            ? "That email already has an account" : "Could not create the account" });
          continue;
        }
        const { error: e2 } = await sb.from("staff").insert({
          id: data.user.id, school_id: schoolId, display_name: name, is_admin: !!a.is_admin,
        });
        if (e2) {
          await sb.auth.admin.deleteUser(data.user.id);
          out.push({ email, display_name: name, error: e2.code === "23505"
            ? "That name is already used at this school - make it different, for example Mrs Patel (Year 3)"
            : "Could not add to the school" });
          continue;
        }
        out.push({ email, display_name: name, is_admin: !!a.is_admin, password });
      }
      return out;
    }

    switch (body.action) {
      case "whoami": {
        const school = me && me.schools && (schoolAdmin || platform)
          ? { id: me.school_id, name: me.schools.name, pair_code: me.schools.pair_code, staff_pin: me.schools.staff_pin } : null;
        return json({
          email: user.email, platform,
          staff: me ? { display_name: me.display_name, school_id: me.school_id, is_admin: me.is_admin, active: me.active } : null,
          school: schoolAdmin ? school : null,
        });
      }

      case "list_schools": {
        if (!platform) return json({ error: "Not allowed" }, 403);
        const { data: schools } = await sb.from("schools").select("id, name, pair_code, staff_pin, created_at").order("created_at");
        const { data: staff } = await sb.from("staff").select("school_id, active");
        return json({ schools: (schools ?? []).map((s) => ({
          ...s, adults: (staff ?? []).filter((t) => t.school_id === s.id && t.active).length,
        })) });
      }

      case "create_school": {
        if (!platform) return json({ error: "Not allowed" }, 403);
        const name = clean(body.name, 120);
        if (!name) return json({ error: "Type the school name." }, 400);
        let school: any = null;
        for (let i = 0; i < 5 && !school; i++) {
          const { data, error } = await sb.from("schools").insert({ name, pair_code: rand(10, CODE) })
            .select("id, name, pair_code, staff_pin").single();
          if (!error) school = data;
        }
        if (!school) return json({ error: "Could not create the school. Try again." }, 500);
        const adults = await createAdults(school.id, body.adults);
        return json({ school, adults });
      }

      case "list_staff": {
        const schoolId = platform && body.school_id ? String(body.school_id) : me?.school_id;
        if (!schoolId || !canManage(schoolId)) return json({ error: "Not allowed" }, 403);
        const { data: staff } = await sb.from("staff").select("id, display_name, is_admin, active").eq("school_id", schoolId).order("display_name");
        const { data: school } = await sb.from("schools").select("id, name, pair_code, staff_pin").eq("id", schoolId).single();
        const { data: users } = await sb.auth.admin.listUsers({ page: 1, perPage: 1000 });
        const emails = new Map((users?.users ?? []).map((u) => [u.id, u.email]));
        return json({ school, staff: (staff ?? []).map((s) => ({ ...s, email: emails.get(s.id) ?? "" })) });
      }

      case "add_adults": {
        const schoolId = String(body.school_id ?? "");
        if (!canManage(schoolId)) return json({ error: "Not allowed" }, 403);
        return json({ adults: await createAdults(schoolId, body.adults) });
      }

      case "set_active":
      case "set_admin":
      case "reset_password": {
        const { data: target } = await sb.from("staff").select("id, school_id, display_name").eq("id", String(body.staff_id ?? "")).maybeSingle();
        if (!target || !canManage(target.school_id)) return json({ error: "Not allowed" }, 403);
        if (target.id === user.id && body.action !== "reset_password") return json({ error: "You can't change your own access." }, 400);
        if (body.action === "set_active") {
          await sb.from("staff").update({ active: !!body.active }).eq("id", target.id);
          return json({ ok: true });
        }
        if (body.action === "set_admin") {
          await sb.from("staff").update({ is_admin: !!body.is_admin }).eq("id", target.id);
          return json({ ok: true });
        }
        const password = rand(12, PW);
        const { error } = await sb.auth.admin.updateUserById(target.id, { password });
        if (error) return json({ error: "Could not reset the password" }, 500);
        const { data: u } = await sb.auth.admin.getUserById(target.id);
        return json({ email: u?.user?.email ?? "", display_name: target.display_name, password });
      }

      case "rotate_secret": {
        const schoolId = String(body.school_id ?? "");
        if (!canManage(schoolId)) return json({ error: "Not allowed" }, 403);
        const patch = body.which === "pin" ? { staff_pin: rand(6, "0123456789") }
          : body.which === "code" ? { pair_code: rand(10, CODE) } : null;
        if (!patch) return json({ error: "Bad request" }, 400);
        const { data, error } = await sb.from("schools").update(patch).eq("id", schoolId).select("pair_code, staff_pin").single();
        if (error) return json({ error: "Could not change it. Try again." }, 500);
        return json(data);
      }

      default:
        return json({ error: "Unknown action" }, 400);
    }
  } catch (_e) {
    return json({ error: "Something went wrong." }, 500);
  }
});
