-- Example onboarding of one school. Replace the values.
-- 1) Create each adult in Supabase > Authentication > Users (email + password, tick "Auto confirm").
-- 2) Run the following, pasting each adult's user id.

insert into public.schools (name, pair_code)
values ('Example Primary School', 'EXAMPLE7')   -- 8+ characters, UPPERCASE, hard to guess
returning id, staff_pin;   -- give the staff PIN to the school: it is needed to disconnect a child tablet

-- Replace <SCHOOL_ID> and <USER_ID>s:
-- insert into public.staff (id, school_id, display_name, is_admin) values
--   ('<USER_ID_1>', '<SCHOOL_ID>', 'Mrs Patel', true),
--   ('<USER_ID_2>', '<SCHOOL_ID>', 'Mr Taylor', false);
