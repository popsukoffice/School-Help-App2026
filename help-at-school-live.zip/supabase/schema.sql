-- Help at School LIVE - Supabase schema (POPS UK)
-- Run in the Supabase SQL editor. Enable Authentication > Providers > "Allow anonymous sign-ins" first.
-- Choose a UK/EU region for the project (children's personal data).

create extension if not exists pgcrypto;

-- ---------- tables ----------
create table public.schools (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  pair_code text not null unique check (pair_code = upper(pair_code) and length(pair_code) >= 8),
  -- Staff PIN needed to disconnect a child tablet. Auto-generated; read it with: select name, staff_pin from schools;
  staff_pin text not null default lpad((floor(random() * 1000000))::int::text, 6, '0') check (staff_pin ~ '^[0-9]{4,8}$'),
  created_at timestamptz not null default now()
);

-- One row per adult who has a login. display_name is what children see in the adult list.
create table public.staff (
  id uuid primary key references auth.users(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete cascade,
  display_name text not null,
  active boolean not null default true,
  is_admin boolean not null default false
);

-- Child tablets (anonymous sign-in) that have been paired to a school with the code.
create table public.devices (
  id uuid primary key,                      -- = auth.uid() of the anonymous session
  school_id uuid not null references public.schools(id) on delete cascade,
  paired_at timestamptz not null default now()
);

create table public.help_requests (
  id uuid primary key,                      -- generated on the tablet so retries are idempotent
  school_id uuid not null references public.schools(id) on delete cascade,
  device_id uuid not null default auth.uid(),
  child_label text check (char_length(child_label) <= 80),   -- first name + year only
  message text not null check (char_length(message) between 1 and 700),
  kind text not null default 'normal' check (kind in ('urgent','private','normal')),
  area text check (char_length(area) <= 80),
  requested_adult text check (char_length(requested_adult) <= 80),
  status text not null default 'new' check (status in ('new','acknowledged','resolved')),
  handled_by uuid references public.staff(id),
  handled_by_name text,
  created_at timestamptz not null default now(),
  handled_at timestamptz
);
create index on public.help_requests (school_id, status, created_at);
create index on public.help_requests (device_id);

-- ---------- helpers ----------
create function public.current_school() returns uuid
language sql stable security definer set search_path = public as $$
  select school_id from public.staff where id = auth.uid() and active
$$;

-- ---------- row level security ----------
alter table public.schools enable row level security;
alter table public.staff enable row level security;
alter table public.devices enable row level security;
alter table public.help_requests enable row level security;

create policy "staff read own school" on public.schools
  for select to authenticated using (id = public.current_school());

create policy "staff read colleagues" on public.staff
  for select to authenticated using (school_id = public.current_school());

create policy "device reads own row" on public.devices
  for select to authenticated using (id = auth.uid());

-- Staff see every request in their school (school-wide queue).
create policy "staff read school requests" on public.help_requests
  for select to authenticated using (school_id = public.current_school());

-- A tablet can read back only its own requests (to show "Mrs Patel is coming").
create policy "device reads own requests" on public.help_requests
  for select to authenticated using (device_id = auth.uid());

-- A tablet can insert only for the school it is paired to, as itself.
create policy "device inserts for its school" on public.help_requests
  for insert to authenticated
  with check (
    device_id = auth.uid()
    and status = 'new'
    and exists (select 1 from public.devices d where d.id = auth.uid() and d.school_id = help_requests.school_id)
  );
-- No update/delete policies: status changes go through handle_request() only.

-- ---------- RPCs ----------
-- Pair a child tablet using the school code. Returns school name + adult names for the dropdown.
create function public.pair_device(p_code text) returns json
language plpgsql security definer set search_path = public as $$
declare s public.schools;
begin
  if auth.uid() is null then return null; end if;
  select * into s from public.schools where pair_code = upper(trim(p_code));
  if not found then return null; end if;
  insert into public.devices (id, school_id) values (auth.uid(), s.id)
    on conflict (id) do update set school_id = excluded.school_id, paired_at = now();
  return json_build_object(
    'school_id', s.id,
    'school_name', s.name,
    'staff', coalesce((select json_agg(display_name order by display_name)
                       from public.staff where school_id = s.id and active), '[]'::json)
  );
end $$;

-- Check the staff PIN from a paired child tablet (used before disconnecting it).
create function public.verify_staff_pin(p_pin text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.devices d join public.schools s on s.id = d.school_id
    where d.id = auth.uid() and s.staff_pin = trim(p_pin)
  )
$$;

-- Staff acknowledge / resolve a request in their school.
create function public.handle_request(p_id uuid, p_status text) returns void
language plpgsql security definer set search_path = public as $$
declare me public.staff;
begin
  if p_status not in ('acknowledged','resolved') then raise exception 'bad status'; end if;
  select * into me from public.staff where id = auth.uid() and active;
  if not found then raise exception 'not staff'; end if;
  update public.help_requests
     set status = p_status,
         handled_by = coalesce(handled_by, me.id),
         handled_by_name = coalesce(handled_by_name, me.display_name),
         handled_at = now()
   where id = p_id and school_id = me.school_id
     and not (status = 'resolved');
end $$;

revoke all on function public.pair_device(text) from public, anon;
revoke all on function public.handle_request(uuid, text) from public, anon;
revoke all on function public.verify_staff_pin(text) from public, anon;
grant execute on function public.verify_staff_pin(text) to authenticated;
grant execute on function public.pair_device(text) to authenticated;
grant execute on function public.handle_request(uuid, text) to authenticated;

-- ---------- realtime ----------
alter publication supabase_realtime add table public.help_requests;

-- ---------- retention (recommended: delete requests after 30 days) ----------
-- create extension if not exists pg_cron;
-- select cron.schedule('help-requests-retention', '15 3 * * *',
--   $$ delete from public.help_requests where created_at < now() - interval '30 days' $$);
-- Also delete stale anonymous devices if you wish:
-- select cron.schedule('devices-retention', '30 3 * * *',
--   $$ delete from public.devices where paired_at < now() - interval '1 year' $$);
