-- Applied to project pquvwrzfpkqfutvxffba on 2026-11-18 (admin tooling).
create table if not exists public.platform_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.platform_admins enable row level security;
revoke all on public.platform_admins from anon, authenticated;
create unique index if not exists staff_school_name_unique on public.staff (school_id, lower(display_name));

-- Make someone a POPS platform admin (can create schools and manage every school):
-- insert into public.platform_admins (user_id) select id from auth.users where email = 'you@example.com';
